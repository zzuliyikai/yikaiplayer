package com.yikai.player.ui.activity

import com.yikai.player.R
import com.yikai.player.base.BaseActivity

class MainActivity : BaseActivity() {
    override fun getLayoutView(): Int {
        return R.layout.activity_main
    }

}
